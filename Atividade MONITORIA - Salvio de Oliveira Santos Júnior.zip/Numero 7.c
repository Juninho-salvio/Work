//7 - A biblioteca de uma Universidade deseja fazer um programa que leia o nome do livro que ser� emprestado, o tipo de usu�rio (professor ou aluno)
//e possa imprimir um recibo conforme mostrado a seguir. Considerar que o professor tem dez dias para devolver o livro e o aluno s� tr�s dias.
//� Nome do livro:
//� Tipo de usu�rio:
//� Total de dias:

#include<stdio.h>
#include<stdlib.h>

main()

{
	char livro[100];
	int tipo;
	
	printf("\n Digite o Nome do livro = ");
	gets(livro);

	printf("\nDigite o tipo de usuario \n");
	printf("1 - professor e 2 - aluno = ");
	scanf("%d", &tipo );
	
	printf("\n\n***********************************************\n\n\n");
	printf("Nome do Livro = %s\n", livro);
	
	if( tipo == 1)
	{
		printf("Tipo de usuario: Professor \nTotal de Dias: 10 dias \n");	
	}
	else
		if( tipo == 2)
		{
			 printf("Tipo de usuario: Aluno \nTotal de Dias: 3 dias \n");
		}
	
}
