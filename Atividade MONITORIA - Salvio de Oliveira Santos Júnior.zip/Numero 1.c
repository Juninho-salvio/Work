//1 - Fa�a um programa em C que receba dois n�meros e ao final imprima a soma, a subtra��o e divis�o destes n�meros.

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

main()

{
	int num1, num2, soma, subtracao;
	float divisao;
	
	printf("\nDigite o primeiro numero: \t ");
	scanf("%d", &num1 );
	
	printf("\nDigite o segundo numero: \t ");
	scanf("%d", &num2 );
	printf("\n\n");
	
	printf("************Resultados*************\n\n\n");
//soma;
	soma = num1 + num2;
	printf("A soma do numero  %d  e  %d  igual a  \t%d ", num1, num2, soma);
	printf("\n");
//subtracao	
	subtracao = num1 - num2;
	printf("A subtra��o de  %d  e %d  eh igual a  \t%d \n", num1, num2, subtracao);
//divisao	
	divisao = num1 / num2;
	if( num2 == 0)
		{
			printf("\nDIVISAO POR ZERO\n");
		}
	else
		{
			printf("A divisao de  %d  e  %d eh igual  %.2f \n\n", num1, num2, divisao);
		}
}
