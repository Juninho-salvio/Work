//4 - Fa�a um programa que imprima os m�ltiplos de 5, no intervalo de 1 at� 300.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int x;
	
	for( x = 0 ; x <= 300 ; x = x+5 )
	{
		printf("\n numeros = %d ", x);
	}
}
