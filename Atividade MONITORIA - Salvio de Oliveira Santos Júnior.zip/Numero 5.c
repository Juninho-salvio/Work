/*5 - Fazer um programa em C onde o usu�rio entre com um valor em metros e imprime o valor correspondente em cent�metros e mil�metros. 
As vari�veis utilizadas dever�o ser do tipo �float� ou �double�.*/

#include<stdio.h>
#include<stdlib.h>

main()

{
	float metros, centimetros, milimetros;
	
	printf("\nDigite o valor em METROS = \t");
	scanf("%f", &metros);
	
	centimetros = metros * 100;
	milimetros  = metros * 1000;
	
	printf("\n*************************************************\n\n");
	printf("*****Valor em CENTIMETROS = %.0f ", centimetros);
	printf("\n\n");
	
	printf("*****Valor em MILIMETROS = %.0f", milimetros);
	printf("\n\n****************************************************\n\n");
	
}
