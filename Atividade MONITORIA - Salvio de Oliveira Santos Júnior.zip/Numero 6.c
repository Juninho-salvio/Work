/*6 - Fa�a um programa que permita entrar com o nome, a nota da prova 1 e a nota da prova 2 de um aluno. 
O programa deve imprimir o nome, a nota da prova 1, a nota da prova 2, a m�dia das notas e uma das mensagens: 
"Aprovado", "Reprovado" ou "em Prova Final"(a m�dia � 7 para aprova��o, menor que 3 para reprova��o e as demais em prova final).*/

#include<stdio.h>
#include<stdlib.h>

main()

{
	char nome[40];
	float prova1, prova2, media;
	
	printf("\nEscreva o nome do aluno = \t");
	gets(nome);
	printf("\n\n");
	
	printf("******* NOTAS DA PROVA ********\n\n");
	printf("\nPROVA 1 = ");
	scanf("%f", &prova1);
	printf("\nPROVA 2 = ");
	scanf("%f", &prova2);
	printf("\n\n\n");
	
	printf("RESULTADO FINAL\n\n");
	printf("O aluno = %s, ", nome);
	printf("\nProva 1 = %.2f", prova1);
	printf("\nProva 2 = %.2f", prova2);
	
	media = (prova1 + prova2) / 2 ;
	
	printf("\nMedia eh = %.2f", media);
	printf("\n\n\nConsidere: \n\n");
	
	if( media >= 7 )
	{ 
		printf("APROVADO\n");
	}
	else
		if( media <= 3)
		{
			printf("REPROVADO\n");
		}
	else
		{
			printf("EM PROVA FINAL\n");
		}
}
