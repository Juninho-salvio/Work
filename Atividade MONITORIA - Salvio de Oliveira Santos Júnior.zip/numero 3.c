//3 - Fa�a um programa que imprima todos os n�meros pares de 100 at� 1.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int num, x;
	
	for( x = 100 ; x >= 1 ; x-- )
	{
		num = x % 2;
		if( num % 2 == 0)
		{
			printf("\nNumero par = %d ", x);
		}
	}
}
