//8 - Fa�a um programa que leia um n�mero inteiro entre 1 e 12 e escreva o m�s correspondente. 
//Caso o usu�rio digite um n�mero fora desse intervalo, dever� aparecer uma mensagem informando que n�o existe m�s com este n�mero. 
//Utilize o switch para este problema.

#include<stdio.h>
#include<stdlib.h>

main()

{
	int mes;
	
	printf("\n digite numero de 1 a 12 para saber o mes corespondente:  ");
	scanf("%d", &mes);
	
	switch(mes)
	{
		case 1:
			printf("\nJANEIRO\n");
		break;
		
		case 2:
			printf("\nFEVEREIRO\n");
		break;
		
		case 3:
			printf("\nMAR�O\n");
		break;
		
		case 4:
			printf("\nABRIL\n");
		break;
		
		case 5:
			printf("\nMAIO\n");
		break;
		
		case 6:
			printf("\nJUNHO\n");
		break;
		
		case 7:
			printf("\nJULHO\n");
		break;
		
		case 8:
			printf("\nAGOSTO\n");
		break;
		
		case 9:
			printf("\nSETEMBRO\n");
		break;
		
		case 10:
			printf("\nOUTUBRO\n");
		break;
		
		case 11:
			printf("\nNOVEMBRO\n");
		break;
		
		case 12:
			printf("\nDEZEMBRO\n");
		break;
		
		default:
			printf("\nNAO EXISTE O MES CORRESPONDE AO NUMERO\n");
	}
}
