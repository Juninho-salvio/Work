//2 - Fa�a um programa em C que leia a base e a altura de um ret�ngulo e imprima o per�metro (base + altura) e a �rea (base * altura).

#include<stdio.h>
#include<stdlib.h>

main()

{
	float base, altura, perimetro, area;
	
	printf("\n*******************************************");
	printf("\nDigite a base do retangulo = \t");
	scanf("%f", &base);
	
	printf("\nDigite a altura do retangulo = \t");
	scanf("%f", &altura);
	printf("\n\n*******************************************\n\n");
	
	perimetro = base + altura ;
	area = ( base * altura);
	
	printf("Perimetro = \t%.2f ", perimetro);
	printf("\nArea = \t%.2f \n", area);
}
